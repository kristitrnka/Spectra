package net.minecraft.inventory;

import javax.annotation.Nullable;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class Slot
{
    private final int field_75225_a;
    public final IInventory field_75224_c;
    public int field_75222_d;
    public int field_75223_e;
    public int field_75221_f;

    public Slot(IInventory p_i1824_1_, int p_i1824_2_, int p_i1824_3_, int p_i1824_4_)
    {
        this.field_75224_c = p_i1824_1_;
        this.field_75225_a = p_i1824_2_;
        this.field_75223_e = p_i1824_3_;
        this.field_75221_f = p_i1824_4_;
    }

    public void func_75220_a(ItemStack p_75220_1_, ItemStack p_75220_2_)
    {
        int i = p_75220_2_.func_190916_E() - p_75220_1_.func_190916_E();

        if (i > 0)
        {
            this.func_75210_a(p_75220_2_, i);
        }
    }

    protected void func_75210_a(ItemStack p_75210_1_, int p_75210_2_)
    {
    }

    protected void func_190900_b(int p_190900_1_)
    {
    }

    protected void func_75208_c(ItemStack p_75208_1_)
    {
    }

    public ItemStack func_190901_a(EntityPlayer p_190901_1_, ItemStack p_190901_2_)
    {
        this.func_75218_e();
        return p_190901_2_;
    }

    public boolean func_75214_a(ItemStack p_75214_1_)
    {
        return true;
    }

    public ItemStack func_75211_c()
    {
        return this.field_75224_c.func_70301_a(this.field_75225_a);
    }

    public boolean func_75216_d()
    {
        return !this.func_75211_c().func_190926_b();
    }

    public void func_75215_d(ItemStack p_75215_1_)
    {
        this.field_75224_c.func_70299_a(this.field_75225_a, p_75215_1_);
        this.func_75218_e();
    }

    public void func_75218_e()
    {
        this.field_75224_c.func_70296_d();
    }

    public int func_75219_a()
    {
        return this.field_75224_c.func_70297_j_();
    }

    public int func_178170_b(ItemStack p_178170_1_)
    {
        return this.func_75219_a();
    }

    @Nullable
    @SideOnly(Side.CLIENT)
    public String func_178171_c()
    {
        return backgroundName;
    }

    public ItemStack func_75209_a(int p_75209_1_)
    {
        return this.field_75224_c.func_70298_a(this.field_75225_a, p_75209_1_);
    }

    public boolean func_75217_a(IInventory p_75217_1_, int p_75217_2_)
    {
        return p_75217_1_ == this.field_75224_c && p_75217_2_ == this.field_75225_a;
    }

    public boolean func_82869_a(EntityPlayer p_82869_1_)
    {
        return true;
    }

    @SideOnly(Side.CLIENT)
    public boolean func_111238_b()
    {
        return true;
    }

    /*========================================= FORGE START =====================================*/
    protected String backgroundName = null;
    protected net.minecraft.util.ResourceLocation backgroundLocation = null;
    protected Object backgroundMap;
    /**
     * Gets the path of the texture file to use for the background image of this slot when drawing the GUI.
     * @return The resource location for the background image
     */
    @SideOnly(Side.CLIENT)
    public net.minecraft.util.ResourceLocation getBackgroundLocation()
    {
        return (backgroundLocation == null ? net.minecraft.client.renderer.texture.TextureMap.field_110575_b : backgroundLocation);
    }

    /**
     * Sets the texture file to use for the background image of the slot when it's empty.
     * @param texture the resourcelocation for the texture
     */
    @SideOnly(Side.CLIENT)
    public void setBackgroundLocation(net.minecraft.util.ResourceLocation texture)
    {
        this.backgroundLocation = texture;
    }

    /**
     * Sets which icon index to use as the background image of the slot when it's empty.
     * @param name The icon to use, null for none
     */
    public void setBackgroundName(@Nullable String name)
    {
        this.backgroundName = name;
    }

    @Nullable
    @SideOnly(Side.CLIENT)
    public net.minecraft.client.renderer.texture.TextureAtlasSprite getBackgroundSprite()
    {
        String name = func_178171_c();
        return name == null ? null : getBackgroundMap().func_110572_b(name);
    }

    @SideOnly(Side.CLIENT)
    protected net.minecraft.client.renderer.texture.TextureMap getBackgroundMap()
    {
        if (backgroundMap == null) backgroundMap = net.minecraft.client.Minecraft.func_71410_x().func_147117_R();
        return (net.minecraft.client.renderer.texture.TextureMap)backgroundMap;
    }

    /**
     * Retrieves the index in the inventory for this slot, this value should typically not
     * be used, but can be useful for some occasions.
     *
     * @return Index in associated inventory for this slot.
     */
    public int getSlotIndex()
    {
        return field_75225_a;
    }

    /**
     * Checks if the other slot is in the same inventory, by comparing the inventory reference.
     * @param other
     * @return true if the other slot is in the same inventory
     */
    public boolean isSameInventory(Slot other)
    {
        return this.field_75224_c == other.field_75224_c;
    }
    /*========================================= FORGE END =====================================*/
}