package net.minecraft.client.renderer.block.model;

import java.util.Arrays;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class BakedQuadRetextured extends BakedQuad
{
    private final TextureAtlasSprite field_178218_d;

    public BakedQuadRetextured(BakedQuad p_i46217_1_, TextureAtlasSprite p_i46217_2_)
    {
        super(Arrays.copyOf(p_i46217_1_.func_178209_a(), p_i46217_1_.func_178209_a().length), p_i46217_1_.field_178213_b, FaceBakery.func_178410_a(p_i46217_1_.func_178209_a()), p_i46217_1_.func_187508_a(), p_i46217_1_.applyDiffuseLighting, p_i46217_1_.format);
        this.field_178218_d = p_i46217_2_;
        this.func_178217_e();
    }

    private void func_178217_e()
    {
        for (int i = 0; i < 4; ++i)
        {
            int j = format.func_181719_f() * i;
            int uvIndex = format.func_177344_b(0) / 4;
            this.field_178215_a[j + uvIndex] = Float.floatToRawIntBits(this.field_178218_d.func_94214_a((double)this.field_187509_d.func_188537_a(Float.intBitsToFloat(this.field_178215_a[j + uvIndex]))));
            this.field_178215_a[j + uvIndex + 1] = Float.floatToRawIntBits(this.field_178218_d.func_94207_b((double)this.field_187509_d.func_188536_b(Float.intBitsToFloat(this.field_178215_a[j + uvIndex + 1]))));
        }
    }

    @Override
    public TextureAtlasSprite func_187508_a()
    {
        return field_178218_d;
    }
}