package net.minecraft.network.play;

import net.minecraft.network.INetHandler;
import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraft.network.play.client.CPacketChatMessage;
import net.minecraft.network.play.client.CPacketClickWindow;
import net.minecraft.network.play.client.CPacketClientSettings;
import net.minecraft.network.play.client.CPacketClientStatus;
import net.minecraft.network.play.client.CPacketCloseWindow;
import net.minecraft.network.play.client.CPacketConfirmTeleport;
import net.minecraft.network.play.client.CPacketConfirmTransaction;
import net.minecraft.network.play.client.CPacketCreativeInventoryAction;
import net.minecraft.network.play.client.CPacketCustomPayload;
import net.minecraft.network.play.client.CPacketEnchantItem;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketInput;
import net.minecraft.network.play.client.CPacketKeepAlive;
import net.minecraft.network.play.client.CPacketPlaceRecipe;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketPlayerAbilities;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.network.play.client.CPacketRecipeInfo;
import net.minecraft.network.play.client.CPacketResourcePackStatus;
import net.minecraft.network.play.client.CPacketSeenAdvancements;
import net.minecraft.network.play.client.CPacketSpectate;
import net.minecraft.network.play.client.CPacketSteerBoat;
import net.minecraft.network.play.client.CPacketTabComplete;
import net.minecraft.network.play.client.CPacketUpdateSign;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.network.play.client.CPacketVehicleMove;

public interface INetHandlerPlayServer extends INetHandler
{
    void func_175087_a(CPacketAnimation p_175087_1_);

    void func_147354_a(CPacketChatMessage p_147354_1_);

    void func_147341_a(CPacketTabComplete p_147341_1_);

    void func_147342_a(CPacketClientStatus p_147342_1_);

    void func_147352_a(CPacketClientSettings p_147352_1_);

    void func_147339_a(CPacketConfirmTransaction p_147339_1_);

    void func_147338_a(CPacketEnchantItem p_147338_1_);

    void func_147351_a(CPacketClickWindow p_147351_1_);

    void func_194308_a(CPacketPlaceRecipe p_194308_1_);

    void func_147356_a(CPacketCloseWindow p_147356_1_);

    void func_147349_a(CPacketCustomPayload p_147349_1_);

    void func_147340_a(CPacketUseEntity p_147340_1_);

    void func_147353_a(CPacketKeepAlive p_147353_1_);

    void func_147347_a(CPacketPlayer p_147347_1_);

    void func_147348_a(CPacketPlayerAbilities p_147348_1_);

    void func_147345_a(CPacketPlayerDigging p_147345_1_);

    void func_147357_a(CPacketEntityAction p_147357_1_);

    void func_147358_a(CPacketInput p_147358_1_);

    void func_147355_a(CPacketHeldItemChange p_147355_1_);

    void func_147344_a(CPacketCreativeInventoryAction p_147344_1_);

    void func_147343_a(CPacketUpdateSign p_147343_1_);

    void func_184337_a(CPacketPlayerTryUseItemOnBlock p_184337_1_);

    void func_147346_a(CPacketPlayerTryUseItem p_147346_1_);

    void func_175088_a(CPacketSpectate p_175088_1_);

    void func_175086_a(CPacketResourcePackStatus p_175086_1_);

    void func_184340_a(CPacketSteerBoat p_184340_1_);

    void func_184338_a(CPacketVehicleMove p_184338_1_);

    void func_184339_a(CPacketConfirmTeleport p_184339_1_);

    void func_191984_a(CPacketRecipeInfo p_191984_1_);

    void func_194027_a(CPacketSeenAdvancements p_194027_1_);
}
