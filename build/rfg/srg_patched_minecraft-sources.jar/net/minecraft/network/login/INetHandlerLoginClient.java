package net.minecraft.network.login;

import net.minecraft.network.INetHandler;
import net.minecraft.network.login.server.SPacketDisconnect;
import net.minecraft.network.login.server.SPacketEnableCompression;
import net.minecraft.network.login.server.SPacketEncryptionRequest;
import net.minecraft.network.login.server.SPacketLoginSuccess;

public interface INetHandlerLoginClient extends INetHandler
{
    void func_147389_a(SPacketEncryptionRequest p_147389_1_);

    void func_147390_a(SPacketLoginSuccess p_147390_1_);

    void func_147388_a(SPacketDisconnect p_147388_1_);

    void func_180464_a(SPacketEnableCompression p_180464_1_);
}
