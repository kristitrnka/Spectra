package net.minecraft.entity.ai.attributes;

import javax.annotation.Nullable;

public interface IAttribute
{
    String func_111108_a();

    double func_111109_a(double p_111109_1_);

    double func_111110_b();

    boolean func_111111_c();

    @Nullable
    IAttribute func_180372_d();
}
